
var data;
var mode;

function start(){

    switch(mode){

        /*case 'risingValue':

            break;
        */
        default:
            self.postMessage(runTime());
            break;

    }

}

function runTime(){
    let t0 = performance.now();
    let j = 0;
    for(let i = 0; i < data.length; i++){
        j++;
    }
    let t1 = performance.now();
    return (t1 - t0);
}

self.addEventListener("message", function(e) {
    
    [data, mode] = e.data;
    
    start();

});