
var sim;


function didStep(){

    //console.log('V: '+sim.getNodeVoltage("CH1"));

    var item1 = sim.getNodeVoltage("CH1");
    var item2 = sim.getNodeVoltage("CH2");
    var item3 = sim.getNodeVoltage("CH3");
    var item4 = sim.getNodeVoltage("CH4");
    
    webworkers.forEach((item) => {
        item.pushData(item1);
    });
    js.forEach((item) => {
        item.pushData(item1);
    });

    if(!webworkerGlobal.triggerFromTiming && webworkerGlobal.activeSim) webworkerExecMeasureSim();
    if(!javascriptGlobal.triggerFromTiming && javascriptGlobal.activeSim) jsExecMeasureSim();

    //sendMessage([sim.getNodeVoltage("CH1"), sim.getNodeVoltage("CH2"), sim.getNodeVoltage("CH3"), sim.getNodeVoltage("CH4")]);
}

function simLoaded() {
    // set up callbacks on timestep and update
    sim = document.getElementById("circuitFrame").contentWindow.CircuitJS1;
    sim.ontimestep = didStep;
    //sim.onupdate = didUpdate;
}

// set up callback
function activateCircuitJS(){
   
    document.getElementById("circuitFrame").contentWindow.oncircuitjsloaded = simLoaded;
    
}