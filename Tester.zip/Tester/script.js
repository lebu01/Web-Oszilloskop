// General JS Management

// Global Variables
var webworkers = [];
var js = [];
var webworkerGlobal = {
    interval: 0,
    intervalRunning: false,
    t0: 0,
    t1: 0,
    triggerFromTiming: true,
    activeSim: false,
    simIterations: 0,
    running: [] // check ob alle durch gelaufen
}
var javascriptGlobal = {
    interval: 0,
    intervalRunning: false,
    t0: 0,
    t1: 0,
    triggerFromTiming: true,
    activeSim: false,
    simIterations: 0,
    running: []
}

const BUNDLED_SIM = 1000;

var circuitJS_local = false;

var dataTransferChannels = [];

// Data Transfer aus anderem Tab
window.addEventListener("message", (event) => {
    console.log("Empfangen vom neuen Tab:", event.data.id);
    //console.log("Empfangen vom neuen Tab:", event.data.text[0]);
    webworkers.forEach((item) => {
        event.data.text.forEach((item1) => {
            item.pushData(item1);
        });
    });
    js.forEach((item) => {
        event.data.text.forEach((item1) => {
            item.pushData(item1);
        });
    });

    if(!webworkerGlobal.triggerFromTiming && webworkerGlobal.activeSim) webworkerExecMeasureSim();
    if(!javascriptGlobal.triggerFromTiming && javascriptGlobal.activeSim) jsExecMeasureSim();
});


/*function updateChannels(){
    for(let ch = 0; ch < dataTransferChannels.length; ch++){
        let channel = dataTransferChannels[ch].ch;

        channel.onmessage = (event) => {
            console.log("Empfangen:", event.data);
            webworkers.forEach((item) => {
                item.pushData(event.data.text[0]);
            });
            js.forEach((item) => {
                item.pushData(event.data.text[0]);
            });
        };
    }
}*/

// Interval Testing
document.getElementById("testButton2").addEventListener("click", function() {
    if(webworkers.length == 0) return;
    webworkerGlobal.intervalRunning = !webworkerGlobal.intervalRunning;
    webworkerTimedController(webworkerGlobal.intervalRunning);
    if(webworkerGlobal.intervalRunning) document.getElementById("testButton2").innerHTML = 'Stop';
    if(!webworkerGlobal.intervalRunning) document.getElementById("testButton2").innerHTML = 'Start';
});

document.getElementById("testButton").addEventListener("click", function() {
    if(js.length == 0) return;
    javascriptGlobal.intervalRunning = !javascriptGlobal.intervalRunning;
    javascriptTimedController(javascriptGlobal.intervalRunning);
    if(javascriptGlobal.intervalRunning) document.getElementById("testButton").innerHTML = 'Stop';
    if(!javascriptGlobal.intervalRunning) document.getElementById("testButton").innerHTML = 'Start';
});

// Data Trigger
document.getElementById("webworker-triggerType").addEventListener("change", function(){
    var elem = document.getElementById("webworker-triggerType");
    if(elem.value == "trigger-by-time") webworkerGlobal.triggerFromTiming = true;
    if(elem.value == "trigger-by-sim") webworkerGlobal.triggerFromTiming = false;
    webworkerGlobal.activeSim = false;
    webworkerGlobal.intervalRunning = false;
    clearInterval(webworkerGlobal.interval);
    document.getElementById("testButton2").innerHTML = 'Start';
    alert('Stopped all running measurements');
});

document.getElementById("js-triggerType").addEventListener("change", function(){
    var elem = document.getElementById("js-triggerType");
    if(elem.value == "trigger-by-time") javascriptGlobal.triggerFromTiming = true;
    if(elem.value == "trigger-by-sim") javascriptGlobal.triggerFromTiming = false;
    javascriptGlobal.activeSim = false;
    javascriptGlobal.intervalRunning = false;
    clearInterval(javascriptGlobal.interval);
    document.getElementById("testButton").innerHTML = 'Start';
    alert('Stopped all running measurements');
});

// CircuitJS Control
document.getElementById("openCircuitJS-sameTab").addEventListener("click", function() {
    circuitJS_local = !circuitJS_local;
    if(circuitJS_local){
        let elem = document.getElementById("circuitJS-sameTab");
        let circuit = `
            <!--<iframe id="outerFrame" src="circuitJS.html" style="height: 100%; width: 100%;"></iframe>-->
            <div id="box"><iframe id="circuitFrame" width="100%" height="500" position="relative" src="circuitjs_new/circuitjs.html?startCircuit=ACcopy.txt" ></iframe> <!-- ?startCircuit=lrc.txt -->
                <div id="infoCircuitJS" style="display: none;"></div>
            </div>
        `;
        elem.innerHTML = circuit;
        elem.style.width = '100%';
        elem.style.height = '100%';
        document.getElementById("openCircuitJS-sameTab").innerHTML = 'CircuitJS schließen';
        activateCircuitJS();
        //simLoaded();
    }else {
        let elem = document.getElementById("circuitJS-sameTab");
        elem.innerHTML = '';
        elem.style.height = '0';
        document.getElementById("openCircuitJS-sameTab").innerHTML = 'CircuitJS gleicher Tab';
    }
});

document.getElementById("openCircuitJS-newTab").addEventListener("click", function() {
    let id = dataTransferChannels.length+1;
    dataTransferChannels.push({chId: id,
        ch: window.open("circuitJS.html?ch="+id, "_blank")});
    //updateChannels();
});

// Create objects
document.getElementById("create-webworker").addEventListener("click", function() {
    var obj = new WebWorkerObj(webworkers.length, document.getElementById("input2").value);
    webworkers.push(obj);
    reloadLists();
});

document.getElementById("create-js").addEventListener("click", function() {
    var obj = new JavaScriptObj(js.length, document.getElementById("input").value);
    js.push(obj);
    reloadLists();
});

// Start / Stop / Change / Remove
function webworkerStartStopBtn(id){
    if(webworkerGlobal.intervalRunning) return;
    var obj = webworkers[id];
    obj.startStop();
}
function webworkerChangeDataAmount(id, elem){
    var obj = webworkers[id];
    obj.setAmount(elem.value);
    reloadLists();
}
function webworkerChangeSelect(id, elem){
    var obj = webworkers[id];
    obj.setDataMode(elem.value);
    reloadLists();
}
function webworkerRemoveObj(id){
    webworkers.splice(id, 1);
    webworkers.forEach((item, idx) => {
        item.setId(idx);
    });
    reloadLists();
}


function jsStartStopBtn(id){
    if(javascriptGlobal.intervalRunning) return;
    var obj = js[id];
    obj.startStop();
}
function jsChangeDataAmount(id, elem){
    var obj = js[id];
    obj.setAmount(elem.value);
    reloadLists();
}
function jsChangeSelect(id, elem){
    var obj = js[id];
    obj.setDataMode(elem.value);
    reloadLists();
}
function jsRemoveObj(id){
    js.splice(id, 1);
    js.forEach((item, idx) => {
        item.setId(idx);
    });
    reloadLists();
}


// WebWorker
class WebWorkerObj {

    constructor(id, amount = 1000) {
        this.id = id;
        this.stdAmount = amount;
        this.running = false;
        this.showResults = false;
        this.dataMode = 'lin';
        this.measure = 'runtime';
        this.webworker = null;
        this.data = [this.stdAmount];
    }
    getId(){
        return this.id;
    }
    setId(id){
        this.id = id;
    }
    setAmount(value){
        this.stdAmount = value;
        this.data = [this.stdAmount];
    }
    setDataMode(value){
        this.dataMode = value;
        this.data = [this.stdAmount];
    }
    startStop(){
        if(this.running){
            this.webworker.terminate();
            this.webworker = undefined;
            this.updateDisplay('stopped')
        }else {
            if(this.data.length <= 1){
                this.runTest();
            }else {
                this.runTest(false);
            }
        }
    }
    runTest(create = true){
        console.error(''+this.data.length);
        console.log('----------------------');
        console.log('Running Test for '+this.id);
        this.running = true;

        // Clean Array
        this.data = this.data.filter((el) => el !== null && el !== undefined);

        // Erstelle Daten
        if(create){
            console.log('Creating Data...');
            this.updateDisplay('createData');
            this.createData();
            console.log('Created Data: '+JSON.stringify(this.data));
        }else {
            console.log('Stored Data: '+JSON.stringify(this.data));
        }


        // Erstelle Webworker
        console.log('Creating Webworker...');
        this.webworker = new Worker("webworker.js");

        console.log('Starting Measurement...');
        this.t0 = performance.now();

        this.updateDisplay('running');
        this.webworker.postMessage([this.data, this.measure]);

        this.webworker.onmessage = (e) => {
            //console.log('Time: '+e.data);
            this.wwDataTime = e.data;
            // Messwertausgabe
            this.t1 = performance.now();
            console.log('Stopping Measurement...');

            this.webworker.terminate();
            this.webworker = undefined;

            console.log('Displaying Results...');
            this.running = false;
            this.showResults = true;
            this.updateDisplay('result');
            webworkerGlobal.running.push(true);
            checkIntervalWebworkerDone();
            console.log('Done!');
            console.log('----------------------');
        }

    }
    setData(data){
        this.data = data;
        this.stdAmount = data.length;
    }
    pushData(data){
        this.data.shift();
        this.data[this.stdAmount-1] = data;
    }
    createData(amount = this.stdAmount){
        this.data.length = 0;
        switch(this.dataMode){
            case 'sin':
                this.data = this.sinData(amount);
                break;

            case 'lin':
                this.data = this.linData(amount);
                break;

            default: // lin
            this.data = this.linData(amount);
                break;

        }
    }
    linData(amount = this.stdAmount){
        let d = [];
        for(let i = 0; i < amount; i++){d.push(i);}
        return d;
    }
    sinData(amount = this.stdAmount, f_signal = 10, f_sampling = 20, amplitude = 1){
        const d = []; // samples
        const dt = 1 / f_sampling; // Zeitintervall zwischen den Abtastpunkten

        for (let n = 0; n < amount; n++) {
            let t = n * dt; // Aktueller Zeitstempel
            let value = amplitude * Math.sin(2 * Math.PI * f_signal * t);
            d.push(value);
        }
        
        return d;
    }
    getState(){
        let state = 'init';
        if(!this.running && this.showResults) state = 'result';
        if(this.running) state = 'running';

        return state;
    }
    getResult(){
        var runtime = this.t1 - this.t0;
        return runtime;
    }
    getDisplay(para = 'init'){
        let out = '';

        let sel = '';
        if(this.dataMode == 'lin') sel = '<option value="lin" selected>lin</option><option value="sin">sin</option>';
        if(this.dataMode == 'sin') sel = '<option value="lin">lin</option><option value="sin" selected>sin</option>';
        let select = '<select onchange="webworkerChangeSelect(\''+this.id+'\', this)">'+sel+'</select>';

        switch (para){
            case 'createData':
                out = `<div class="webworker-obj" obj="`+this+`" id="ww-`+this.id+`">
                        <button onclick="webworkerStartStopBtn('`+this.id+`')">Stop</button>
                        <br>
                        <div>Erstelle Datenwerte...</div>
                    </div>`;
                break;
            
            case 'running':
                out = `<div class="webworker-obj" obj="`+this+`" id="ww-`+this.id+`">
                        <button onclick="webworkerStartStopBtn('`+this.id+`')">Stop</button>
                        <br>
                        <div>Führe Messung durch...</div>
                    </div>`;
                break;

            case 'result':
                out = `<div class="webworker-obj" obj="`+this+`" id="ww-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="webworkerChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="webworkerStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <details>
                            <summary>Datenwerte (`+this.data.length+`)</summary>
                            <p>`+this.data+`</p>
                        </details>
                        <div>Laufzeit: `+this.getResult().toFixed(6)+`ms; Datenverarb. in Webworker: `+this.wwDataTime.toFixed(6)+`ms; Übertragungszeit: `+(this.getResult().toFixed(6) - this.wwDataTime.toFixed(6))+`ms</div>
                        <div onclick="webworkerRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

            case 'stopped':
                out = `<div class="webworker-obj" obj="`+this+`" id="ww-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="webworkerChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="webworkerStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <div>Abbruch der Messung!</div>
                        <div onclick="webworkerRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

            default:
                out = `<div class="webworker-obj" obj="`+this+`" id="ww-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="webworkerChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="webworkerStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <div></div>
                        <div onclick="webworkerRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

        }
        
        return out;
    }
    updateDisplay(state){
        var elem = document.getElementById("ww-"+this.id);
        elem.innerHTML = this.getDisplay(state);
    }
}

// JavaScript
class JavaScriptObj {

    constructor(id, amount = 1000) {
        this.id = id;
        this.stdAmount = amount;
        this.running = false;
        this.showResults = false;
        this.dataMode = 'lin';
        this.measure = 'runtime';
        this.data = [this.stdAmount];
    }
    getId(){
        return this.id;
    }
    setId(id){
        this.id = id;
    }
    setAmount(value){
        this.stdAmount = value;
        this.data = [this.stdAmount];
    }
    setDataMode(value){
        this.dataMode = value;
        this.data = [this.stdAmount];
    }
    startStop(){
        if(this.running){
            this.updateDisplay('stopped')
        }else {
            if(this.data.length <= 1){
                this.runTest();
            }else {
                this.runTest(false);
            }
        }
    }
    runTest(create = true){
        console.log('----------------------');
        console.log('Running Test for '+this.id);
        this.running = true;

        // Clean Array
        this.data = this.data.filter((el) => el !== null && el !== undefined);

        // Erstelle Daten
        if(create){
            console.log('Creating Data...');
            this.updateDisplay('createData');
            this.createData();
            console.log('Created Data: '+JSON.stringify(this.data));
        }else {
            console.log('Stored Data: '+JSON.stringify(this.data));
        }

        // Messung
        console.log('Starting Measurement...');
        this.updateDisplay('running');
        this.t0 = performance.now();
        this.doOperation();

        
        // Messwertausgabe
        this.t1 = performance.now();
        console.log('Stopping Measurement...');


        console.log('Displaying Results...');
        this.running = false;
        this.showResults = true;
        this.updateDisplay('result');
        javascriptGlobal.running.push(true);
        checkIntervalJavaScriptDone();
        console.log('Done!');
        console.log('----------------------');

    }
    doOperation(){
        switch(this.measure){
            case 'risingValue':

                break;

            default: // runtime
                this.measureRuntime();
                break;
        }
    }
    measureRuntime(){
        let j = 0;
        for(let i = 0; i < this.data.length; i++){
            j++;
        }
        return 'done';
    }
    setData(data){
        this.data = data;
        this.stdAmount = data.length;
    }
    pushData(data){
        this.data.shift();
        this.data[this.stdAmount] = data;
    }
    createData(amount = this.stdAmount){
        this.data.length = 0;
        switch(this.dataMode){
            case 'sin':
                this.data = this.sinData(amount);
                break;

            case 'lin':
                this.data = this.linData(amount);
                break;

            default: // lin
            this.data = this.linData(amount);
                break;

        }
    }
    linData(amount = this.stdAmount){
        let d = [];
        for(let i = 0; i < amount; i++){d.push(i);}
        return d;
    }
    sinData(amount = this.stdAmount, f_signal = 10, f_sampling = 20, amplitude = 1){
        const d = []; // samples
        const dt = 1 / f_sampling; // Zeitintervall zwischen den Abtastpunkten

        for (let n = 0; n < amount; n++) {
            let t = n * dt; // Aktueller Zeitstempel
            let value = amplitude * Math.sin(2 * Math.PI * f_signal * t);
            d.push(value);
        }
        
        return d;
    }
    getState(){
        let state = 'init';
        if(!this.running && this.showResults) state = 'result';
        if(this.running) state = 'running';

        return state;
    }
    getResult(){
        var runtime = this.t1 - this.t0;
        return runtime;
    }
    getDisplay(para = 'init'){
        let out = '';

        let sel = '';
        if(this.dataMode == 'lin') sel = '<option value="lin" selected>lin</option><option value="sin">sin</option>';
        if(this.dataMode == 'sin') sel = '<option value="lin">lin</option><option value="sin" selected>sin</option>';
        let select = '<select onchange="jsChangeSelect(\''+this.id+'\', this)">'+sel+'</select>';

        switch (para){
            case 'createData':
                out = `<div class="js-obj" obj="`+this+`" id="js-`+this.id+`">
                        <button onclick="jsStartStopBtn('`+this.id+`')">Stop</button>
                        <br>
                        <div>Erstelle Datenwerte...</div>
                    </div>`;
                break;
            
            case 'running':
                out = `<div class="js-obj" obj="`+this+`" id="js-`+this.id+`">
                        <button onclick="jsStartStopBtn('`+this.id+`')">Stop</button>
                        <br>
                        <div>Führe Messung durch...</div>
                    </div>`;
                break;

            case 'result':
                out = `<div class="js-obj" obj="`+this+`" id="js-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="jsChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="jsStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <details>
                            <summary>Datenwerte (`+this.data.length+`)</summary>
                            <p>`+this.data+`</p>
                        </details>
                        <div>Laufzeit: `+this.getResult().toFixed(6)+`ms</div>
                        <div onclick="jsRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

            case 'stopped':
                out = `<div class="js-obj" obj="`+this+`" id="js-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="jsChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="jsStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <div>Abbruch der Messung!</div>
                        <div onclick="jsRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

            default:
                out = `<div class="js-obj" obj="`+this+`" id="js-`+this.id+`">
                        <input type="number" value="`+this.stdAmount+`" name="amountData" onchange="jsChangeDataAmount('`+this.id+`', this)" placeholder="Anzahl Daten">
                        `+select+`
                        <button onclick="jsStartStopBtn('`+this.id+`')">Start</button>
                        <br>
                        <div></div>
                        <div onclick="jsRemoveObj('`+this.id+`')" class="remove-obj">✕</div>
                    </div>`;
                break;

        }
        
        return out;
    }
    updateDisplay(state){
        var elem = document.getElementById("js-"+this.id);
        elem.innerHTML = this.getDisplay(state);
    }
}


// Controller
function webworkerTimedController(start){
    if(start){
        console.log('Starting interval measurement...');
        if(webworkerGlobal.triggerFromTiming) webworkerExecMeasureTime();
        if(!webworkerGlobal.triggerFromTiming) webworkerGlobal.activeSim = true;
    }else {
        console.log('Stopping interval measurement...');
        if(webworkerGlobal.triggerFromTiming) clearInterval(webworkerGlobal.interval);
        if(!webworkerGlobal.triggerFromTiming) webworkerGlobal.activeSim = false;
    }
}

function webworkerExecMeasureTime(){
    webworkerGlobal.interval = setInterval(function(){
        if(webworkerGlobal.running.length < webworkers.length) console.log((webworkers.length - webworkerGlobal.running.length)+' measurements did not finish!');
        webworkerGlobal.running.length = 0;
        webworkerGlobal.t0 = performance.now();
        webworkers.forEach((item) => {
            if(item.getState() != 'running'){
                item.startStop();
            }else {
                console.log('Skipped measurement for id '+item.getId()+' -> still measuring');
            }
        });
    }, 5000);
}

function webworkerExecMeasureSim(){
    webworkerGlobal.simIterations++;
    webworkerGlobal.t0 = performance.now();
    if(webworkerGlobal.simIterations >= BUNDLED_SIM){
        webworkerGlobal.simIterations = 0;
        if(webworkerGlobal.running.length < webworkers.length) console.log((webworkers.length - webworkerGlobal.running.length)+' measurements did not finish!');
        webworkerGlobal.running.length = 0;
        webworkers.forEach((item) => {
            if(item.getState() != 'running'){
                item.startStop();
            }else {
                console.log('Skipped measurement for id '+item.getId()+' -> still measuring');
            }
        });
    }
}

function javascriptTimedController(start){
    if(start){
        console.log('Starting interval measurement...');
        if(javascriptGlobal.triggerFromTiming) jsExecMeasureTime();
        if(!javascriptGlobal.triggerFromTiming) javascriptGlobal.activeSim = true;
    }else {
        console.log('Stopping interval measurement...');
        if(javascriptGlobal.triggerFromTiming) clearInterval(javascriptGlobal.interval);
        if(!javascriptGlobal.triggerFromTiming) javascriptGlobal.activeSim = false;
    }
}

function jsExecMeasureTime(){
    javascriptGlobal.interval = setInterval(function(){
        if(javascriptGlobal.running.length < js.length) console.log((js.length - javascriptGlobal.running.length)+' measurements did not finish!');
        javascriptGlobal.running.length = 0;
        javascriptGlobal.t0 = performance.now();
        js.forEach((item) => {
            if(item.getState() != 'running'){
                item.startStop();
            }else {
                console.log('Skipped measurement for id '+item.getId()+' -> still measuring');
            }
        });
    }, 5000);
}

function jsExecMeasureSim(){
    javascriptGlobal.simIterations++;
    javascriptGlobal.t0 = performance.now();
    if(javascriptGlobal.simIterations >= BUNDLED_SIM){
        javascriptGlobal.simIterations = 0;
        if(javascriptGlobal.running.length < js.length) console.log((js.length - javascriptGlobal.running.length)+' measurements did not finish!');
        javascriptGlobal.running.length = 0;
        js.forEach((item) => {
            if(item.getState() != 'running'){
                item.startStop();
            }else {
                console.log('Skipped measurement for id '+item.getId()+' -> still measuring');
            }
        });
    }
}

// Functions
function reloadLists(){
    var elemWw = document.getElementById("webworker-objects");
    elemWw.innerHTML = '';

    webworkers.forEach((item/*, idx*/) => {
        let state = item.getState();
        elemWw.innerHTML = elemWw.innerHTML + item.getDisplay(state);
    });

    var elemJs = document.getElementById("js-objects");
    elemJs.innerHTML = '';

    js.forEach((item/*, idx*/) => {
        let state = item.getState();
        elemJs.innerHTML = elemJs.innerHTML + item.getDisplay(state);
    });
}

function checkIntervalWebworkerDone(){
    if(webworkerGlobal.running.length == webworkers.length){
        webworkerGlobal.t1 = performance.now();
        if(webworkerGlobal.triggerFromTiming) document.getElementById("data-out2").innerHTML = "Laufzeit "+webworkers.length+" Webworker: "+(webworkerGlobal.t1 - webworkerGlobal.t0).toFixed(6) + "ms";
        if(!webworkerGlobal.triggerFromTiming) document.getElementById("data-out2").innerHTML = "Laufzeit "+webworkers.length+" Webworker: "+(webworkerGlobal.t1 - webworkerGlobal.t0).toFixed(6) + "ms ("+BUNDLED_SIM+" bundled)";
    }
}

function checkIntervalJavaScriptDone(){
    if(javascriptGlobal.running.length == js.length){
        javascriptGlobal.t1 = performance.now();
        if(javascriptGlobal.triggerFromTiming) document.getElementById("data-out").innerHTML = "Laufzeit "+js.length+" JavaScript: "+(javascriptGlobal.t1 - javascriptGlobal.t0).toFixed(6) + "ms";
        if(!javascriptGlobal.triggerFromTiming) document.getElementById("data-out").innerHTML = "Laufzeit "+js.length+" JavaScript: "+(javascriptGlobal.t1 - javascriptGlobal.t0).toFixed(6) + "ms ("+BUNDLED_SIM+" bundled)";
    }
}