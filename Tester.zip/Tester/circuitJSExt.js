var win;

if (window.opener) {
    win = window.opener;
}

const params = new URLSearchParams(window.location.search);
const chId = params.get("ch");
//const channel = new BroadcastChannel("channel"+chId);

var sim;

var isBundled = false;

var bundled = 0;
var sendData = [];

// Menu
document.getElementById("closeFrame").addEventListener("click", function() {
    if(confirm('Soll der Tab wirklich geschlossen werden?')) window.close();
});

// Datenübertrageung aus anderem Tab
function sendMessage(message) {
    win.postMessage({ id: chId, text: message, timestamp: new Date().toISOString() });
    console.log("Gesendet:", message);
}


function didStep(){
    if(isBundled){
        bundled++;
        if(bundled <= 1000){
            sendData.push(sim.getNodeVoltage("CH1"));
        }else {
            sendMessage(sendData);
            sendData = [];
            bundled = 0;
        }
    }else {
        sendMessage([sim.getNodeVoltage("CH1")]);
    }
    
    

    //sendMessage([sim.getNodeVoltage("CH1"), sim.getNodeVoltage("CH2"), sim.getNodeVoltage("CH3"), sim.getNodeVoltage("CH4")]);
}

function simLoaded() {
    // set up callbacks on timestep and update
    sim = document.getElementById("circuitFrame").contentWindow.CircuitJS1;
    sim.ontimestep = didStep;
    //sim.onupdate = didUpdate;
}

// set up callback
document.getElementById("circuitFrame").contentWindow.oncircuitjsloaded = simLoaded;