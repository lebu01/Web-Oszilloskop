const CACHE_NAME = 'circuitjs1-app-cache-v1';
const path = '';
const urlsToCache = [
  path+'about.html',
  path+'canvas2svg.js',
  path+'circuitjs.html',
  path+'crystal.html',
  path+'customfunction.html',
  path+'customlogic.html',
  path+'customtransformer.html',
  path+'diodecalc.html',
  path+'icon512.png',
  path+'icon128.png',
  path+'iframe.html',
  path+'lz-string.min.js',
  path+'manifest.json',
  path+'mexle.html',
  path+'mosfet-beta.html',
  path+'opampreal.html',
  path+'split.js',
  path+'subcircuits.html',
  // put everything else here
];

self.addEventListener('install', event => {
  event.waitUntil(
    caches.open(CACHE_NAME)
      .then(cache => cache.addAll(urlsToCache))
  );
});

self.addEventListener('fetch', (event) => {
    event.respondWith(
        caches.match(event.request).then((cachedResponse) => {
            if (cachedResponse) {
                // If the resource is already cached, return it
                return cachedResponse;
            }

            // Otherwise, fetch it from the network and add it to the cache
            return fetch(event.request).then((networkResponse) => {
                // Only cache non-GET requests and responses that aren't errors
                if (
                    event.request.method === 'GET' &&
                    networkResponse.status === 200
                ) {
		    const responseClone = networkResponse.clone();
                    caches.open(CACHE_NAME).then((cache) => {
                        cache.put(event.request, responseClone);
                    });
                }

                return networkResponse;
            });
        })
    );
});


// Activate event: cleans up old caches
self.addEventListener('activate', (event) => {
    const cacheWhitelist = [CACHE_NAME];  // List of cache versions you want to keep

    event.waitUntil(
        caches.keys().then((cacheNames) => {
            return Promise.all(
                cacheNames.map((cacheName) => {
                    if (!cacheWhitelist.includes(cacheName)) {
                        return caches.delete(cacheName);  // Delete old caches that aren't in whitelist
                    }
                })
            );
        })
    );
});
