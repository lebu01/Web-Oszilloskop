var sim;
var webworker;

var div = document.getElementById("oszi");
var backgroundCanvas = document.getElementById("display-background");
var graphsCanvas = document.getElementById("graphs");
var menuCanvas = document.getElementById("menu");
var linesCanvas = document.getElementById("lines");
var triggerCanvas = document.getElementById("triggerCanvas");
var statsCanvas = document.getElementById("stats");
var backgroundCtx = backgroundCanvas.getContext("2d");
var graphsCtx = graphsCanvas.getContext("2d");
var menuCtx = menuCanvas.getContext("2d");
var linesCtx = linesCanvas.getContext("2d");
var triggerCtx = triggerCanvas.getContext("2d");
var statsCtx = statsCanvas.getContext("2d");

var bundledCycles = 250;//default number of data stamps when drawing without changing time resolution
var ringBufferSize = 2500; //max index number of ring buffer
var triggerArea = 251; //number of cycles that get checked for trigger, minimum is value of bundled Cycles, triggerAreas overlap, so that no pulse etc. stays undetected; should maybe be made relative to trigger mode e.g. Edge practically just needs bundledCycles+1
var screenData;
var triggerBuffer; //copies ringBuffer if signal is triggered
var ringBuffer;
var stepCounter = 0;
var drawTime = 0;


var oszi = {
    simVisible: false,
    elements: [],
    init: function() {
        // canvas Einstellungen
        div.style.height = 602/640 * div.offsetWidth + "px";// change scale depending on space needed for new elements/measurements of real oscilloscope
        backgroundCanvas.width = div.clientWidth;
        backgroundCanvas.height = div.clientHeight;

        // initialize oszi-elements
        osziScreen.setPos(0.0, -0.08, 1.0, 1.0);
        this.button1 = new Button(0.10, 0.85, 0.08, 0.05, 1);
        this.button2 = new Button(0.25, 0.85, 0.08, 0.05, 2);
        this.button3 = new Button(0.40, 0.85, 0.08, 0.05, 3);
        this.button4 = new Button(0.55, 0.85, 0.08, 0.05, 4);
        this.button5 = new Button(0.70, 0.85, 0.08, 0.05, 5);
        this.button6 = new Button(0.85, 0.85, 0.08, 0.05, 6);
        /*this.triggerButton = new Button(0.65, 0.05, 0.08, 0.04, "Trigger");
        this.modeCouplingButton = new Button(0.65, 0.1, 0.08, 0.04, "Mode Coupling");
        this.measurementButton = new Button(0.65, 0.15, 0.08, 0.04, "Meas");*/

        // initialize menu
        osziSettings.setMenu();
        //osziSettings.openMenu("Trigger Menu", [0, 1, 2]);
    
        backgroundCanvas.addEventListener("mouseup", (event) => {
            for(element of this.elements) {
                if(element.isInside(event.pageX - 9, event.pageY - 9)) {
                    osziSettings.pressButton(element.name);
                    break;
                }
            }
        });
        backgroundCanvas.addEventListener("mousemove", (event) => {
            for(element of this.elements) {
                if(element.isInside(event.pageX - 9, event.pageY - 9)) {
                    element.highlight();
                    break;
                } else {
                    element.draw();
                }
            }
        });
        window.addEventListener("resize", (event) => {
            div.style.height = 602/640 * div.offsetWidth + "px";// change scale depending on space needed for new elements/measurements of real oscilloscope
            backgroundCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
            backgroundCanvas.width = div.clientWidth;
            backgroundCanvas.height = div.clientHeight;
            osziScreen.updatePos();
            for(element of this.elements) {
                element.updatePos();
            }
            osziSettings.updateMenu();
            osziScreen.draw(screenData);
        });

        // Initialize Webworker
        webworker = new Worker("display/worker.js");
        webworker.addEventListener("message", function(messageEvent) {
            triggerBuffer = Object.assign({}, ringBuffer);
            //let leftBoundary = messageEvent.data - stepCounter + 0.5*(ringBufferSize-triggerArea) - osziSettings.triggerPos*bundledCycles;
            
            //                    Differenzrechnung zwischen   | start des Triggerbereichs innerhalb    alle 250 cycles * 0,5
            //                    Flankenwert und tatsächlichen| des Ringpuffers     
            // Was mit vergangenen Steps während Berechnung?
            // Problem mit                     
            let leftBoundary = messageEvent.data - stepCounter + 0.5*(ringBufferSize-triggerArea) - osziSettings.triggerPos*bundledCycles;

            /*let stepFraction = (messageEvent.data % 250) / 250;  // Wo liegt die Flanke zwischen zwei Step-Updates?
            let interpolatedStepCounter = stepCounter + (messageEvent.data % 250);  // Interpolierter Wert

            let leftBoundary = messageEvent.data - interpolatedStepCounter + 0.5 * (ringBufferSize - triggerArea) - osziSettings.triggerPos * bundledCycles;
            */

            /*console.log('---------------------------');
            /*console.log('Boundry: '+leftBoundary);*
            console.log('---------------------------');
            console.log('messageEvent.data:', messageEvent.data);
            console.log('stepCounter:', stepCounter);
            console.log('ringBufferSize:', ringBufferSize);
            console.log('triggerArea:', triggerArea);
            console.log('osziSettings.triggerPos:', osziSettings.triggerPos);
            console.log('bundledCycles:', bundledCycles);
            console.log('Berechnetes leftBoundary:', leftBoundary);*
            console.log("Flanke gefunden bei:", messageEvent.data);
            console.log("Aktueller stepCounter:", stepCounter);
            console.log("Differenz (Flankenversatz):", messageEvent.data - stepCounter);

            console.log('---------------------------');*/

            screenData.getData(leftBoundary, leftBoundary + triggerArea);
            osziScreen.draw(screenData);
        });
        console.log('Init webworker for Trigger');

    },
    toggleIFrame: function() {
        if(this.simVisible) {
          document.getElementById("circuitFrame").style.display = "none";
        } else {
          document.getElementById("circuitFrame").style.display = "";
        }
        this.simVisible = !this.simVisible;
    }
}

//SETTINGS/MENU:
var osziSettings = {
    menu: null,
    menuOptions: null,
    menuSettings: [0, 0, 0, 0],//adapt to number of menu options/menu.length, saves only the index of the chosen setting in the submenu-array
    activeMenu: null,
    menuName: null,
    activeSubmenu: null,
    triggerActivated: true,
    triggerThreshold: 5,
    triggerPos: 0.5,//position of trigger time on screen, value 0 (left) - 1 (right)
    activeChannels: [true, false, false, false],
    
    //Menu functions:
    setMenu: function() {
        /*0*/let triggerMode = ["Edge", "Edge then Edge", "Pulswidth", "Bytepattern", "Or", "Rise/Falltime", "N Edge Burst", "Low Pulse", "Setup and Hold", "Video", "USB"];
        /*1*/let triggerSource = ["1", "2", "3", "4", "Extern", "Net", "Waveform-Gen", "Wavefom-Gen MOD (FSK/FM)"];
        /*2*/let triggerFlag = ["Rising", "Falling", "Alternating", "Either"];
        /*3*/let modeCoupling = ["Normal", "Auto"];
        /* empty menus for later integration
        let cursor = [];
        let measurement = [];
        let analyse = [];
        let aquire = [];
        let display = [];
        let saveRecall = [];
        let horizontal = [];
        let navigate = [];
        let calculation = [];
        let refWaveForm = [];
        let channel1 = [];
        let channel2 = [];
        let channel3 = [];
        let channel4 = [];
        let help = [];
        */

        this.menu = [triggerMode, triggerSource, triggerFlag, modeCoupling];
    },
    pressButton: function(buttonName) {
        if(typeof buttonName === 'string') {
            if(this.activeMenu != buttonName) {
                this.closeMenu();
                this.closeSubmenu();
                this.activeMenu = buttonName;
                switch(buttonName) {
                    case "Trigger":
                        this.openMenu("Trigger Menu", [0, 1, 2]);
                        break;
                    case "Mode Coupling":
                        this.openMenu("Mode Coupling", [3]);
                        break;
                    case "Meas":
                        this.openMenu("Measurement", []);
                        break;
                    default:
                        console.log("Button " + buttonName + " not found!");
                }
            }
        } else {
            if(this.activeSubmenu == buttonName - 1) {// go to next option of submenu
                this.openSubmenu(true);
            } else {// open new submenu, close old one if necessary
                //alert(''+buttonName);
                if(this.activeSubmenu != null) {
                    this.closeSubmenu();
                }
                //alert(''+buttonName);
                this.activeSubmenu = buttonName - 1;
                this.openSubmenu(false);
            }
        }
    },
    openMenu: function(menuName, menuOptions) {
        this.menuName = menuName;
        this.menuOptions = menuOptions;
        menuCtx.fillStyle = "black";
        menuCtx.fillRect(0, 0.58 * osziScreen.height, osziScreen.width, 0.11 * osziScreen.height);
        menuCtx.strokeStyle = "white";
        menuCtx.lineWidth = 1;
        menuCtx.strokeRect(0, 0.85 * menuCanvas.height, menuCanvas.width, 0.15 * menuCanvas.height);
        menuCtx.font = "15px Arial";
        menuCtx.fillStyle = "white";
        menuCtx.textAlign = "left";
        menuCtx.fillText(menuName, 0.02 * osziScreen.width, 0.61 * osziScreen.height);
        menuCtx.textAlign = "center";
        for(let i = 0; i < menuOptions.length; i++) {
            menuCtx.fillText(this.menu[menuOptions[i]][this.menuSettings[menuOptions[i]]], (i/6 + 0.1) * osziScreen.width, 0.66 * osziScreen.height, 1/6 * osziScreen.width);//possible max width 
        }
    },
    updateMenu: function() {
        if(this.activeMenu != null) {
            this.openMenu(this.menuName, this.menuOptions);
            if(this.activeSubmenu != null) {
                this.openSubmenu(false);
            }
        }
    },
    closeMenu: function() {
        this.menuName = null;
        this.activeMenu = null;
        this.activeSubmenu = null;
        this.menuOptions = null;
        menuCtx.clearRect(0, 0.85 * osziScreen.height, osziScreen.width, 0.15 * osziScreen.height);
    },
    openSubmenu: function(stepMode) {
        if(this.menuOptions != null) {
            if(this.menu[this.menuOptions[this.activeSubmenu]] != null) {
                if(stepMode) {
                    menuCtx.clearRect(0, 0, osziScreen.width, osziScreen.height);
                    if(this.menuSettings[this.menuOptions[this.activeSubmenu]] < this.menu[this.menuOptions[this.activeSubmenu]].length - 1) {
                        this.menuSettings[this.menuOptions[this.activeSubmenu]]++;
                    } else {
                        this.menuSettings[this.menuOptions[this.activeSubmenu]] = 0;
                    }
                    this.openMenu(this.menuName, this.menuOptions);
                }
                //draw submenu background
                menuCtx.strokeStyle = "white";
                menuCtx.lineWidth = 2;
                menuCtx.fillStyle = "black";
                menuCtx.beginPath();
                //menuCtx.roundRect(this.activeSubmenu/6 * osziScreen.width, (0.84 - 0.05 * (this.menu[this.menuOptions[this.activeSubmenu]].length+1)) * osziScreen.height, 1/6*osziScreen.width, (0.05 + 0.026 * (this.menu[this.menuOptions[this.activeSubmenu]].length))*osziScreen.height, 0.01*osziScreen.width);
                //menuCtx.roundRect(this.activeSubmenu/6 * osziScreen.width, (0.55 - 0.026 * (this.menu[this.menuOptions[this.activeSubmenu]].length+1)) * osziScreen.height, 1/6*osziScreen.width, (0.05 + 0.026 * (this.menu[this.menuOptions[this.activeSubmenu]].length))*osziScreen.height, 0.01*osziScreen.width);
                menuCtx.roundRect(this.activeSubmenu/6 * osziScreen.width, (0.55 - 0.023 * (this.menu[this.menuOptions[this.activeSubmenu]].length+1)) * osziScreen.height, 1/6*osziScreen.width, (0.05 + 0.023 * (this.menu[this.menuOptions[this.activeSubmenu]].length))*osziScreen.height, 0.01*osziScreen.width);
                //alert(''+(this.menu[this.menuOptions[this.activeSubmenu]].length+1));
                menuCtx.stroke();
                menuCtx.fill();

                //draw menu options
                for(let i = 0; i < this.menu[this.menuOptions[this.activeSubmenu]].length; i++) {
                    if(i == this.menuSettings[this.menuOptions[this.activeSubmenu]]) {
                        menuCtx.fillStyle = "green";
                    } else {
                        menuCtx.fillStyle = "white";
                    }
                    menuCtx.textAlign = "left";
                    menuCtx.fillText(this.menu[this.menuOptions[this.activeSubmenu]][i], (this.activeSubmenu/6 + 1/40) * osziScreen.width, (0.585 + 0.026 * (i - this.menu[this.menuOptions[this.activeSubmenu]].length)) * osziScreen.height, 2/15*osziScreen.width);
                }
            }
        }
    },
    closeSubmenu: function() {
        this.activeSubmenu = null;
        menuCtx.clearRect(0, 0, osziScreen.width, 0.58 * osziScreen.height);
    },
    getSetting: function(settingNumber) {
        return this.menu[settingNumber][this.menuSettings[settingNumber]];
    },

    //Trigger functions
    updateTrigger: function() {
        //this.triggerThreshold = parseFloat(document.getElementById("tThreshold").value);
        //this.triggerPos = parseFloat(document.getElementById("triggerPos").value);
    },
    toggleTrigger: function() {
        this.triggerActivated = !this.triggerActivated;
        if(this.triggerActivated) {
            /*document.getElementById("Trigger").textContent = "Trigger: ON";
            webworker = new Worker("display/worker.js");
            console.log('Enabled Trigger with '+webworker);
            webworker.addEventListener("message", function(messageEvent) {
                triggerBuffer = Object.assign({}, ringBuffer);
                let leftBoundary = messageEvent.data - stepCounter + 0.5*(ringBufferSize-triggerArea) - osziSettings.triggerPos*bundledCycles;
                screenData.getData(leftBoundary, leftBoundary + triggerArea);
                console.log('Male Daten');
                osziScreen.draw(screenData);
            });*/
        } else {
            document.getElementById("Trigger").textContent = "Trigger: OFF";
            webworker.terminate();
            stepCounter = 0;
            drawTime = 0;
        }
    },
    toggleChannelActivation: function(channel, buttonName = 'Kanal 1') {
        let status = this.activeChannels[channel];
        this.activeChannels[channel] = !status;
        return status; // Änderung Bulling
    },
    setChannelState: function(channel, value = false) { // Änderung Bulling
        this.activeChannels[channel] = value;
    }
}

//VISUALISATION ELEMENTS:
var osziScreen = {
    x_rel: 0,
    y_rel: 0,
    width_rel: 0,
    height_rel: 0,
    xpoint: 0,
    ypoint: 0,
    width: 0,
    height: 0,
    posX: 0,
    posY: 0,
    innerWidth: 0,
    innerHeight: 0,
    xSquare: 0,
    ySquare: [0, 0, 0, 0],
    xScale: 0,
    yScale: [0, 0, 0, 0],
    tps: 0.1, // time per square in s
    vps: [5.0, 5.0, 5.0, 5.0], // voltage per square in V
    channelColor: ["yellow", "lightgreen", "lightblue", "pink"],
    offset: 0, // offset |
    offsetVertical: [0, 0, 0, 0], // offset --
    triggerOffset: 0,
    triggerVisibleTimer: 0,

    setPos: function(x_rel, y_rel, width_rel, height_rel) {
        this.x_rel = x_rel;
        this.y_rel = y_rel;
        this.width_rel = width_rel;
        this.height_rel = height_rel;
        this.updatePos();
    },
    updatePos: function() {
        this.xpoint = Math.round(this.x_rel * backgroundCanvas.width);
        this.ypoint = Math.round(this.y_rel * backgroundCanvas.width);
        this.width = Math.round(this.width_rel * backgroundCanvas.width);
        this.height = Math.round(this.height_rel * backgroundCanvas.width);
        this.innerWidth = 5/7 * this.width;
        this.innerHeight = 2/4 * this.height;

        let offsetTop = (backgroundCanvas.height - (this.height_rel*this.innerHeight))/2;
        this.posX = this.xpoint + (this.width / 40);
        this.posY = this.ypoint + offsetTop + (this.height / 30);

        // adapt canvas graphs to new dimensions
        graphsCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        graphsCanvas.style.left = this.posX + "px";
        graphsCanvas.style.top = this.posY + "px";
        graphsCanvas.width = this.innerWidth;
        graphsCanvas.height = this.innerHeight;
        // adapt canvas menu to new dimensions
        menuCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        menuCanvas.style.left = this.xpoint + "px";
        menuCanvas.style.top = (this.posY-40) + "px";
        menuCanvas.width = this.width;
        menuCanvas.height = (11 * (this.innerHeight / 8));   
        //menuCanvas.height = this.height;     
        this.drawIncrements();

        // Draw Offset Lines
        //this.drawOffsetLines();
        linesCanvas.style.left = this.posX + "px";
        linesCanvas.style.top = this.posY + "px";
        linesCanvas.width = this.innerWidth;
        linesCanvas.height = this.innerHeight;

        // Draw Trigger
        this.drawTriggerLevel();
        triggerCanvas.style.left = this.posX + "px";
        triggerCanvas.style.top = this.posY + "px";
        triggerCanvas.width = this.innerWidth;
        triggerCanvas.height = this.innerHeight;

        // Draw Stats
        statsCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
        statsCanvas.style.left = this.xpoint + "px";
        statsCanvas.style.top = (this.posY - 40) + "px";
        statsCanvas.width = this.width;
        statsCanvas.height = 11 * (this.innerHeight / 8);
        this.drawStats();
    },
    drawIncrements: function() {// Zeichnen des Oszilloskop Bildschirm Hintergrund    
        backgroundCtx.fillStyle = "#DDD";
        //backgroundCtx.fillStyle = "#FF0000";
        backgroundCtx.fillRect(this.xpoint, this.ypoint, this.width, this.height);

        //Schwarzer Streifen des Displays
        backgroundCtx.fillStyle = "#000";
        backgroundCtx.fillRect(this.xpoint, this.posY-40, this.width, (11 * (this.innerHeight / 8)));

        backgroundCtx.beginPath();
        //backgroundCtx.strokeStyle = "#f5f5f5";
        backgroundCtx.strokeStyle = "#999";
        // draw Horizontal Lines
        for(let i = 0; i < 9; i++) {
            backgroundCtx.moveTo(this.posX, (this.posY + i * (this.innerHeight / 8)));
            backgroundCtx.lineTo((this.posX + this.innerWidth), (this.posY + i * (this.innerHeight / 8)));
        }
        // draw Vertical Lines
        for(let i = 0; i < 11; i++) {
            backgroundCtx.moveTo(this.posX + i * (this.innerWidth / 10), this.posY);
            backgroundCtx.lineTo((this.posX + i * (this.innerWidth / 10)), (this.posY + this.innerHeight));  
        }
        // draw Horizontal Increments
        for(let i = 0; i < 41; i++) {
            backgroundCtx.moveTo((this.posX + this.innerWidth * 0.49), (this.posY + i * (this.innerHeight / 40)));
            backgroundCtx.lineTo((this.posX + this.innerWidth * 0.51), (this.posY + i * (this.innerHeight / 40)));
        }
        // draw Vertical Increments
        for(let i = 0; i < 41; i++) {
            backgroundCtx.moveTo(this.posX + i * (this.innerWidth / 40), this.posY + this.innerHeight * 0.49);
            backgroundCtx.lineTo((this.posX + i * (this.innerWidth / 40)), (this.posY + this.innerHeight * 0.51));
        }
        backgroundCtx.stroke();       
        backgroundCtx.closePath();
    },
    draw: function(buffer) {
        screenData = buffer;
        graphsCtx.clearRect(0, 0, this.width, this.height);

        /*this.xSquare = parseFloat(this.tps); // Änderung Bulling
        this.ySquare = parseFloat(this.vps); // Änderung Bulling
        document.getElementById("tps").innerHTML = this.tps;
        //document.getElementById("vps").innerHTML = this.vps;
        this.xScale = this.innerWidth / (10 * this.xSquare); // Breite Kästchen
        this.yScale = this.innerHeight / (8 * this.ySquare);*/
        //document.getElementById("vps").innerHTML = this.vps;
        let channelData = [buffer.CH1, buffer.CH2, buffer.CH3, buffer.CH4];
        //let channelColor = ["yellow", "lightgreen", "lightblue", "pink"];
        
        for(var i = 0; i <= 3; i++) {
            this.xSquare = parseFloat(this.tps); // Änderung Bulling
            this.ySquare[i] = parseFloat(this.vps[i]); // Änderung Bulling
            this.xScale = this.innerWidth / (10 * this.xSquare); // Breite Kästchen
            this.yScale[i] = this.innerHeight / (8 * this.ySquare[i]);

            if(osziSettings.activeChannels[i]) {
                graphsCtx.strokeStyle = this.channelColor[i];
                this.drawChart(channelData[i], buffer.timeSteps, i);
            }
        }
    },
    drawOffsetLines: function(){

        linesCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);
    
        let mid = this.innerWidth/2 + this.offset;

        linesCtx.fillStyle = "orange"; // Falls du das Dreieck füllen willst
        linesCtx.strokeStyle = "orange";
        linesCtx.beginPath();

        // Spitze nach unten, Mitte des Dreiecks liegt bei "mid"
        linesCtx.moveTo(mid, 6);  // Spitze des Dreiecks (unten)
        linesCtx.lineTo(mid - 8, 0); // Linke obere Ecke (8px nach links)
        linesCtx.lineTo(mid + 8, 0); // Rechte obere Ecke (8px nach rechts)
        linesCtx.fill();
        linesCtx.closePath();

        for(var i = 0; i < 4; i++){
            let midVert = this.innerHeight/2 + this.offsetVertical[i];
            // Spitze nach rechts, Mitte des Dreiecks liegt bei "mid"
            linesCtx.beginPath();
            linesCtx.moveTo(6, midVert);  // Spitze des Dreiecks (links)
            linesCtx.lineTo(0, midVert - 8); // Obere Ecke (8px nach oben)
            linesCtx.lineTo(0, midVert + 8); // Untere Ecke (8px nach unten)
            linesCtx.fill();
            linesCtx.closePath();
        }

        //graphsCtx.strokeStyle = "orange";
        linesCtx.beginPath();
        linesCtx.moveTo(mid, 0);
        linesCtx.setLineDash([5, 8]);

        linesCtx.lineTo(mid, this.innerHeight);

        linesCtx.stroke();
        linesCtx.closePath();
        linesCtx.setLineDash([]);
        
    },
    drawChart: function(channelData, timeSteps, channel) {// Zeichnen der Messwerte
        graphsCtx.beginPath();
        graphsCtx.moveTo(0, this.innerHeight/2 - channelData[0]*this.yScale[channel]);
        let xCoord = 0;
        for(let i = 1; i < channelData.length; i++) {
            xCoord = xCoord + timeSteps[i];
            graphsCtx.lineTo(xCoord*this.xScale, this.innerHeight/2 - channelData[i]*this.yScale[channel]);
        }
        graphsCtx.stroke();
        graphsCtx.closePath();
    },
    drawStats: function(){
        statsCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);

        // Headline

        for(let i = 0; i < 4; i++){

            // Voltage
            const fontSize = 12;
            statsCtx.font = fontSize+"px Arial";
            statsCtx.textAlign = "left";
            statsCtx.textBaseline = "middle"
            statsCtx.fillStyle = this.channelColor[i];

            let vol = this.vps[i] + 'V';
            if(this.vps[i] < 1 && this.vps[i] >= 0.001) vol = (this.vps[i] * 1000) + 'mV';
            if(this.vps[i] < 0.001) vol = (this.vps[i] * 1000000) + 'µV';

            let text = (i+1)+"    "+vol;
            let textMetrics = statsCtx.measureText(text);
            let textWidth = textMetrics.width;

            //let fontHeight = textMetrics.actualBoundingBoxAscent + textMetrics.actualBoundingBoxDescent || (fontSize * 0.8);
            
            //statsCtx.fillText(text, this.posX + (i * (textWidth + 25)), (40/2)); // Y-Koordinate anpassen ############################################
            statsCtx.fillText(text, this.posX + (i * (45 + 25)), (40/2));
        
        }

        // Time per Square
        statsCtx.fillStyle = "white";

        let time = this.tps + 's';
        if(this.tps < 1 && this.tps > 0.001) time = Math.round(this.tps * 1000) + "ms";
        if(this.tps <= 0.001 && this.tps > 0.000001) time = Math.round(this.tps * 1000000) + 'µs';
        if(this.tps <= 0.000001) time = Math.round(this.tps * 1000000000) + 'ns';

        text = time;
        let textMetricsTime = statsCtx.measureText(text);
        let textWidthTime = textMetricsTime.width;

        statsCtx.fillText(text, (this.posX + 80 + (4 * (45 + 25))), (40/2));
        
        // Time offset

        // xScale = 1 Kästchen
        time = Math.round(this.offset/this.xScale * this.tps);
        if(this.tps < 1 && this.tps > 0.001) time = Math.round(this.offset/this.xScale * this.tps * 10000) + 'ms';
        if(this.tps <= 0.001) time = Math.round(this.offset/this.xScale * this.tps * 10000000) + 'µs';

        if(this.xScale == 0){
            time = '0s';
            if(this.tps < 1 && this.tps > 0.001) time = '0ms';
            if(this.tps < 0.001) time = '0µs';
        }else {
            time = Math.round(this.offset/this.xScale * this.tps)+'s';
            if(this.tps < 1 && this.tps > 0.001) time = Math.round(this.offset/this.xScale * this.tps * 10000) + 'ms';
            if(this.tps <= 0.001) time = Math.round(this.offset/this.xScale * this.tps * 10000000) + 'µs';
        }

        text = time;
        statsCtx.fillText(text, (this.posX + 140 + (4 * (45 + 25))), (40/2));

        // Trigger Value
        var idx = 3;
        //if(osziSettings != null) idx = osziSettings.getSetting(1) - 1;
        text = (Math.round(osziSettings.triggerThreshold *100)/100)+'V';
        if(this.vps[idx] < 1 && this.vps[idx] > 0.001) text = (Math.round(osziSettings.triggerThreshold*10000 *100)/100)+'mV';
        if(this.vps[idx] <= 0.001) text = (Math.round(osziSettings.triggerThreshold*10000000 *100)/100)+'µV';

        statsCtx.fillText(text, (this.posX + 300 + (4 * (45 + 25))), (40/2));
        
    },
    drawTriggerLevel: function(){
        clearTimeout(this.triggerVisibleTimer);
        triggerCtx.clearRect(0, 0, window.innerWidth, window.innerHeight);

        triggerCtx.fillStyle = "red"; // Falls du das Dreieck füllen willst
        triggerCtx.strokeStyle = "red";

        if(this.yScale[0] == 0){ // Falls noch keine Zuweisung stattgefunden hat
            for(var i = 0; i <= 3; i++) {
                this.xSquare = parseFloat(this.tps); // Änderung Bulling
                this.ySquare[i] = parseFloat(this.vps[i]); // Änderung Bulling
                this.xScale = this.innerWidth / (10 * this.xSquare); // Breite Kästchen
                this.yScale[i] = this.innerHeight / (8 * this.ySquare[i]);
            }
        }

        osziSettings.triggerThreshold = (this.triggerOffset/100 * 5 * this.vps[0]);
        let midVert = this.innerHeight/2 - (this.triggerOffset/100 * this.yScale[0]*this.ySquare[0] * 5); // mit *this.ySQuare, das yScale abhängig in Nenner
        //document.getElementById('tThreshold').value = osziSettings.triggerThreshold;
        //document.getElementById('tThreshold').disabled = true;
        console.log(this.vps[0]+'; '+this.yScale[0]+'; '+this.ySquare[0]);

        // Spitze nach rechts, Mitte des Dreiecks liegt bei "mid"
        triggerCtx.beginPath();
        triggerCtx.moveTo(6, midVert);  // Spitze des Dreiecks (links)
        triggerCtx.lineTo(0, midVert - 8); // Obere Ecke (8px nach oben)
        triggerCtx.lineTo(0, midVert + 8); // Untere Ecke (8px nach unten)
        triggerCtx.fill();
        triggerCtx.closePath();

        triggerCtx.beginPath();
        triggerCtx.moveTo(0, midVert);
        triggerCtx.setLineDash([5, 8]);

        triggerCtx.lineTo(this.innerWidth, midVert);

        triggerCtx.stroke();
        triggerCtx.closePath();
        triggerCtx.setLineDash([]);

        this.triggerVisibleTimer = setTimeout(() => {
            console.log('Reset Trigger Line');
            triggerCtx.clearRect(6, 0, window.innerWidth, window.innerHeight); // alles löschen außer dreieck
        }, 2000);
    },
        
};

class Button {
    constructor(x_rel, y_rel, width_rel, height_rel, name) {
        this.x_rel = x_rel;
        this.y_rel = y_rel;
        this.width_rel = width_rel;
        this.height_rel = height_rel;
        this.name = name;//either number for unnamed buttons in the bottom or button tag
        this.xpoint = 0;
        this.ypoint = 0;
        this.width = 0;
        this.height = 0;
        oszi.elements.push(this);
        this.updatePos();
    }
    updatePos() {
        this.xpoint = Math.round(this.x_rel * backgroundCanvas.width);
        this.ypoint = Math.round(this.y_rel * backgroundCanvas.width);
        this.width = Math.round(this.width_rel * backgroundCanvas.width);
        this.height = Math.round(this.height_rel * backgroundCanvas.width);
        this.draw();
    }
    draw() {
        backgroundCtx.fillStyle = "grey";
        backgroundCtx.fillRect(this.xpoint, this.ypoint, this.width, this.height);
        backgroundCtx.strokeStyle = "black";
        backgroundCtx.lineWidth = 1;
        backgroundCtx.strokeRect(this.xpoint, this.ypoint, this.width, this.height);
        if(typeof this.name === 'string') {
            backgroundCtx.font = "15px Arial";
            backgroundCtx.fillStyle = "black";
            backgroundCtx.textAlign = "center";
            backgroundCtx.textBaseline = "middle";
            backgroundCtx.fillText(this.name, this.xpoint + this.width/2, this.ypoint + this.height/2, this.width);
        }
    }
    isInside(xmouse, ymouse) {
        const distanceX = this.xpoint + this.width;
        const distanceY = this.ypoint + this.height;
        if(xmouse >= this.xpoint && xmouse <= distanceX && ymouse >= this.ypoint && ymouse <= distanceY) {
            return true;
        } else {
            return false;
        } 
    }
    highlight() {
        backgroundCtx.strokeStyle = "black";
        backgroundCtx.lineWidth = 2;
        backgroundCtx.strokeRect(this.xpoint + 1, this.ypoint + 1, this.width - 2, this.height - 2);
    }
}

//DATA MANAGEMENT:
class Buffer {
    constructor() {
        this.CH1 = [];
        this.CH2 = [];
        this.CH3 = [];
        this.CH4 = [];
        this.timeSteps = [];
    }
    pushData() {//only used by ringBuffer
        if(osziSettings.activeChannels[0]){
            this.CH1.shift();
            this.CH1[ringBufferSize] = sim.getNodeVoltage("CH1");
        }/*else {
            this.CH1.length = 0;
        }*/
        if(osziSettings.activeChannels[1]){
            this.CH2.shift();
            this.CH2[ringBufferSize] = sim.getNodeVoltage("CH2");
        }/*else {
            this.CH2.length = 0;
        }*/
        if(osziSettings.activeChannels[2]){
            this.CH3.shift();
            this.CH3[ringBufferSize] = sim.getNodeVoltage("CH3");
        }/*else {
            this.CH3.length = 0;
        }*/
        if(osziSettings.activeChannels[3]){
            this.CH4.shift();
            this.CH4[ringBufferSize] = sim.getNodeVoltage("CH4");
        }/*else {
            this.CH4.length = 0;
        }*/

        this.timeSteps.shift();
        this.timeSteps[ringBufferSize] = sim.getTimeStep();
    }
    getData(startIndex, endIndex) {//getting data from ringBuffer
        this.CH1 = ringBuffer.CH1.slice(startIndex, endIndex);
        this.CH2 = ringBuffer.CH2.slice(startIndex, endIndex);
        this.CH3 = ringBuffer.CH3.slice(startIndex, endIndex);
        this.CH4 = ringBuffer.CH4.slice(startIndex, endIndex);
        this.timeSteps = ringBuffer.timeSteps.slice(startIndex, endIndex);
    }
    checkTrigger() {
        let triggerValues = eval("this.CH" + osziSettings.getSetting(1) + ".slice(0.5*(ringBufferSize-triggerArea), 0.5*(ringBufferSize+triggerArea))");//change, when other trigger sources than input channels 1-4 are implemented
        let triggerMode = osziSettings.getSetting(0);
        //osziSettings.updateTrigger();
        //console.log('CH: '+osziSettings.getSetting(1));
        /*if(webworker !== undefined)*/webworker.postMessage([triggerValues, triggerMode, osziSettings.getSetting(2), osziSettings.triggerThreshold, stepCounter]);//send timeSteps for more complex trigger modi
        //console.log('triggerValues: '+triggerValues+'; triggerMode: '+triggerMode+'; setting: '+osziSettings.getSetting(2)+'; threshold: '+osziSettings.triggerThreshold+'; stepCounter: '+stepCounter);
    }
}

/*Code to measure processing speed of programm segment
var t0 = performance.now();
var t1 = performance.now();
console.log(`Durchlauf dauerte ${t1 - t0} Millisekunden.`);
*/

var t1 = 0;
var t0 = 0;

function didStep() {
    t1 = performance.now();
    //console.clear();
    //console.log(`Durchlauf dauerte ${t1 - t0} Millisekunden.`);
    ringBuffer.pushData();
    stepCounter++;
    if(osziSettings.triggerActivated) {
        if(stepCounter%bundledCycles == 0) {
            ringBuffer.checkTrigger();
        }
    } /*else {
        //console.log('bef '+sim.getTimeStep()+'; '+);
        drawTime = drawTime + sim.getTimeStep();
        if(drawTime >= 10*osziScreen.xSquare) {
            screenData.getData(ringBufferSize - stepCounter, ringBufferSize);
            osziScreen.draw(screenData);
            stepCounter = 0;
            drawTime = 0;
        }
        //osziScreen.drawOffsetLines();
    }*/
    if(osziScreen.xSquare != 0) {
        sim.setMaxTimeStep(10*osziScreen.xSquare / bundledCycles);
        //sim.setMaxTimeStep(0.000005);
        //sim.setMaxTimeStep(1);
    }

    osziScreen.drawOffsetLines();
    t0 = performance.now();
}

function round(x) {
    return Math.round(x*1000)/1000;
}
  
// called when simulator updates its display
function didUpdate() {
    var info = document.getElementById("infoCircuitJS");
    info.innerHTML = "time = " + round(sim.getTime()) + "<br>running = " + sim.isRunning();
    var bstr = "";
    var bval = 0;
    var i;
    for (i = 7; i >= 0; i--) {
        var v = sim.getNodeVoltage("D" + i);
        if (v > 2.5) {
            bstr += "1";
            bval = 2*bval+1;
        } else {
            bstr += "0";
            bval = 2*bval;
        }
    }
    info.innerHTML += "<br>counter value = <tt>" + bstr + "</tt> = " + bval;
  
    // go through list of elements
    var elmList = sim.getElements();
    var rcount = 0;
    for (const elm of elmList) {
        if (elm.getType() == "ResistorElm") {
            // show info about each resistor
            rcount++;
            info.innerHTML += "<br>resistor " + rcount + " voltage diff = " + round(elm.getVoltageDiff());
            info.innerHTML += "<br>resistor " + rcount + " current = " + round(elm.getCurrent() * 1000) + " mA";
        } else if (elm.getType() == "LabeledNodeElm") {
            // show voltage of each labeled node
            info.innerHTML += "<br>V(" + elm.getLabelName() + ") = " + round(elm.getVoltage(0));
        }
    }
}

//INITIATION:
function simLoaded() {
    // set up callbacks on timestep and update
    sim = document.getElementById("circuitFrame").contentWindow.CircuitJS1;
    sim.ontimestep = didStep;
    sim.onupdate = didUpdate;


    screenData = new Buffer();
    ringBuffer = new Buffer();
}

oszi.init();

// set up callback
document.getElementById("circuitFrame").contentWindow.oncircuitjsloaded = simLoaded;


