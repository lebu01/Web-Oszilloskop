//worker acts parallel to the rest of the programm to check a segment of old data for possible triggers

var data, triggerMode, triggerFlag, triggerThreshold, startIndex;
var triggerFunc;//function pointer for current trigger mode; only gets changed, if trigger mode is changed
var flagFunc;//function pointer for current trigger flag; only gets changed, if trigger flag is changed
var secondEdge = false;
var alternating = false;

//TRIGGER MODE FUNCTIONS:
function edgeTrigger() {
  //console.log('On Edge');
  for(var i = 0; i < data.length-1; i++) {
    if(flagFunc(data[i], data[i + 1])) {
      /*console.log('1: '+data[i]+'; 2: '+data[i+1]);
      console.log('Th: '+triggerThreshold);
      console.log('idx: '+startIndex);*/
      startIndex = startIndex + i;
      self.postMessage(startIndex);
      data.splice(0, i + 1);
      edgeTrigger();
      break;
    }
  }
}

/*
function edgeTrigger() {
  if (typeof startIndex === 'undefined') {
    startIndex = 0;  // Sicherheitshalber setzen
  }

  let i = 0;
  while (i < data.length - 1) {
    if (flagFunc(data[i], data[i + 1])) {
      console.log("Flanke erkannt bei Index:", i);
      startIndex += i;
      console.log("Neuer StartIndex:", startIndex);
      self.postMessage(startIndex);
      data.splice(0, i + 1);  // Entferne alle bis zur Flanke
      i = 0;  // Zurücksetzen, um im gekürzten Array neu zu starten
    } else {
      i++;
    }
  }
}*/


function edgeThenEdgeTrigger() {
  for(var i = 0; i < data.length; i++) {
    if(flagFunc(data[i], data[i + 1])) {
      startIndex = startIndex + i;
      data.splice(0, i + 1);
      if(secondEdge) {
        self.postMessage(startIndex);
      }
      secondEdge = !secondEdge;
      edgeThenEdgeTrigger();
      break;
    }
  }
}

//add functions for rest of trigger modes

function getTriggerFunc(newTriggerMode) {
  switch(newTriggerMode) {
    case "Edge":
      triggerFunc = edgeTrigger;
      break;
    case "Edge then Edge":
      triggerFunc = edgeThenEdgeTrigger;
      break;
    default:
      console.log("Error: Unknown triggerMode!")  
      return;
  }
}

//FLAG FUNCTIONS:
function risingFlag(data_1, data_2) {
  /*console.log('------------');
  console.log('Rising Flag: '+triggerThreshold);
  console.log('data_1: '+data_1+'; data_2: '+data_2);
  console.log('------------');*/
  if(data_1 < triggerThreshold && data_2 >= triggerThreshold) {
    return true;
  }
  return false;
}

function fallingFlag(data_1, data_2) {
  if(data_1 > triggerThreshold && data_2 <= triggerThreshold) {
    return true;
  }
  return false;
}

function alternatingFlag(data_1, data_2) {
  if(alternating) {
    if(data_1 > triggerThreshold && data_2 <= triggerThreshold) {
      return true;
    }
  } else {
    if(data_1 < triggerThreshold && data_2 >= triggerThreshold) {
      return true;
    }
  }
  return false;
}

function eitherFlag(data_1, data_2) {
  if((data_1 < triggerThreshold && data_2 >= triggerThreshold) || (data_1 > triggerThreshold && data_2 <= triggerThreshold)) {
    return true;
  }
  return false;
}

function getFlagFunc(newFlag) {
  switch(newFlag) {
    case "Rising":
      flagFunc = risingFlag;
      break;
    case "Falling":
      flagFunc = fallingFlag;
      break;
    case "Alternating":
      flagFunc = alternatingFlag;
    case "Either":
      flagFunc = eitherFlag;
      break;
    default:
      console.log("Trigger flag error!")
      return;
  }    
}

self.addEventListener("message", function(messageEvent) {
  //console.log('Trigger enabled');
  if(messageEvent.data[1] != triggerMode) {
    getTriggerFunc(messageEvent.data[1]);
  }
  if(messageEvent.data[2] != triggerFlag) {
    getFlagFunc(messageEvent.data[2]);
  }
  [data, triggerMode, triggerFlag, triggerThreshold, startIndex] = messageEvent.data;
  
  triggerFunc();
});